from app import app

#flask --app airbnb.py --debug run